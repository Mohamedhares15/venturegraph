"use client";
import {
  ComposedChart, BarChart, Bar, Line, Cell,
  ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ReferenceLine,
} from "recharts";
import { Card } from "@/components/ui/Card";
import { Section } from "@/components/ui/Section";
import { StatusPill } from "@/components/ui/StatusPill";

// Inline ETF_SECTOR so this client component has no server-only imports
const ETF_SECTOR: Record<string, string> = {
  IGV: "iShares Expanded Tech-Software",
  SOXX: "iShares Semiconductor",
  XBI: "SPDR S&P Biotech",
  XLF: "Financial Select Sector",
  FDN: "First Trust Internet",
};

const SECTOR_COLOURS: Record<string, string> = {
  IGV: "#8a6a14", SOXX: "#7c3aed", XBI: "#0e7a3f", XLF: "#a35a00", FDN: "#1a4f8b",
};

interface SmsRow {
  eval_date?: string;
  sector?: string;
  sms_score?: number;
  n_silent?: number;
  n_expected?: number;
}

interface CorrRow {
  horizon?: string | number;
  alpha_col?: string;
  pearson_r?: number;
  p_value?: number;
  n_obs?: number;
  signal_dir?: string;
}

interface Props {
  sectorStats: { sector: string; name: string; latest_score: number; mean_sms: number; n_obs: number }[];
  multiSectorTs: Record<string, string | number>[];
  topEvents: { date: string; sector: string; score: number; n_silent?: number; n_expected?: number }[];
  corrRows: CorrRow[];
  sectors: string[];
}

export function SmsEngineCharts({ sectorStats, multiSectorTs, topEvents, corrRows, sectors }: Props) {
  return (
    <>
      {/* Per-sector summary */}
      <Section label="Sector overview" title="Latest SMS score by ETF sector">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {sectorStats.map((s) => (
            <div key={s.sector} className="sov-metric-card">
              <div className="sov-metric-label">{s.sector}</div>
              <div className="sov-metric-value">{s.latest_score.toFixed(3)}</div>
              <div className="sov-metric-sub">μ = {s.mean_sms.toFixed(3)} · {s.n_obs} obs</div>
            </div>
          ))}
        </div>
      </Section>

      {/* Multi-sector overlay */}
      {multiSectorTs.length > 0 && (
        <Section label="Signal history" title="SMS across all five sectors">
          <Card>
            <p className="text-[0.84rem] text-ink-500 mb-3">
              Higher = more silence. Spikes signal that smart money has pulled back from a sector.
            </p>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={multiSectorTs} margin={{ top: 8, right: 24, left: 4, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" minTickGap={36} tick={{ fontSize: 10 }} />
                  <YAxis tickFormatter={(v) => Number(v).toFixed(2)} />
                  <Tooltip formatter={(v: unknown) => [Number(v).toFixed(3), ""]} />
                  <Legend />
                  {sectors.map((sec) => (
                    <Line
                      key={sec}
                      type="monotone"
                      dataKey={sec}
                      stroke={SECTOR_COLOURS[sec]}
                      strokeWidth={2}
                      dot={false}
                      connectNulls
                      name={`${sec} (${ETF_SECTOR[sec] ?? sec})`}
                    />
                  ))}
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </Section>
      )}

      {/* Top silence events */}
      <Section label="Silence events" title="Highest-intensity SMS readings">
        <Card>
          <div className="overflow-x-auto">
            <table className="sov-table">
              <thead>
                <tr><th>#</th><th>Date</th><th>Sector</th><th>SMS Score</th><th>n_silent</th><th>n_expected</th></tr>
              </thead>
              <tbody>
                {topEvents.map((e, i) => (
                  <tr key={i}>
                    <td className="num text-gold-700 font-semibold">{i + 1}</td>
                    <td className="num">{e.date}</td>
                    <td><span className="font-mono text-[0.8rem] font-semibold text-ink-900">{e.sector}</span></td>
                    <td className="num font-semibold">{e.score.toFixed(4)}</td>
                    <td className="num">{e.n_silent ?? "—"}</td>
                    <td className="num">{e.n_expected ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </Section>

      {/* Alpha correlation */}
      {corrRows.length > 0 && (
        <Section label="Predictive power" title="SMS → Fama-French α lead-lag correlation">
          <Card variant="ok">
            <p className="text-[0.84rem] text-ink-600 mb-4">
              Pre-registered hypothesis H₂: SMS predicts sector alpha at lead horizons 1–12 months.
            </p>
            <div className="grid lg:grid-cols-2 gap-4">
              <div className="overflow-auto max-h-[320px]">
                <table className="sov-table">
                  <thead>
                    <tr><th>Horizon</th><th>Alpha col</th><th>r</th><th>p-value</th><th>n</th><th>Dir</th></tr>
                  </thead>
                  <tbody>
                    {corrRows.map((r, i) => (
                      <tr key={i}>
                        <td className="num">{r.horizon}</td>
                        <td className="font-mono text-[0.78rem]">{r.alpha_col}</td>
                        <td className={`num font-semibold ${Number(r.pearson_r) > 0 ? "text-ok-700" : "text-risk-700"}`}>
                          {Number(r.pearson_r).toFixed(4)}
                        </td>
                        <td className="num">{Number(r.p_value).toFixed(4)}</td>
                        <td className="num">{r.n_obs}</td>
                        <td><StatusPill className="!text-[0.58rem]">{String(r.signal_dir)}</StatusPill></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="h-[320px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={corrRows.map((r) => ({ horizon: r.horizon, r: Number(r.pearson_r) }))}
                    margin={{ top: 4, right: 20, left: 4, bottom: 4 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="horizon" />
                    <YAxis tickFormatter={(v) => Number(v).toFixed(2)} />
                    <Tooltip formatter={(v: unknown) => [Number(v).toFixed(4), "Pearson r"]} />
                    <ReferenceLine y={0} stroke="#94a3b8" />
                    <Bar dataKey="r" radius={[3, 3, 0, 0]}>
                      {corrRows.map((r, i) => (
                        <Cell key={i} fill={Number(r.pearson_r) > 0 ? "#0e7a3f" : "#d04444"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </Card>
        </Section>
      )}
    </>
  );
}
