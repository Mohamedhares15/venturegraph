// Catch-all dynamic page for the 18 modules that haven't been hand-built yet.
// Renders a polished "coming next session" view with the real metadata + a
// preview of the underlying live data so the page never feels empty.
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import * as Icons from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { ModuleHero } from "@/components/ui/ModuleHero";
import { Card, CardLabel } from "@/components/ui/Card";
import { StatusPill } from "@/components/ui/StatusPill";
import { Section } from "@/components/ui/Section";
import { MetricCard } from "@/components/ui/MetricCard";
import { moduleBySlug } from "@/lib/modules";
import { loadSnapshot } from "@/lib/data";
import { Sparkles, ArrowRight, Wrench } from "lucide-react";
import Link from "next/link";
import { fmtInt } from "@/lib/utils";

const FLOOR_LABELS: Record<string, string> = {
  F1: "FLOOR 01 · WORKFLOW",
  F2: "FLOOR 02 · DEEP ANALYSIS",
  F3: "FLOOR 03 · SIGNAL ENGINE",
  F4: "FLOOR 04 · TRUST & AUDIT",
  F5: "FLOOR 05 · REGIONAL & META",
};

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const m = moduleBySlug(slug);
  if (!m) return { title: "Not found · VentureGraph Sovereign" };
  return { title: `${m.title} · VentureGraph Sovereign` };
}

export default async function ModuleStub({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const m = moduleBySlug(slug);
  if (!m) notFound();

  const snap = await loadSnapshot();
  const Icon = (Icons[m.icon as keyof typeof Icons] as LucideIcon) || Icons.Sparkles;

  return (
    <div className="sov-fade-up">
      <ModuleHero
        num={m.num}
        floor={FLOOR_LABELS[m.floor]}
        title={m.title}
        tagline={m.tagline}
        actions={
          <>
            <StatusPill variant="info">
              <Wrench size={11} strokeWidth={2} />
              Phase 2
            </StatusPill>
            <StatusPill>{m.id}</StatusPill>
          </>
        }
      >
        {m.description}
      </ModuleHero>

      {/* Hero preview card */}
      <Card variant="info" className="mb-6 !p-7">
        <div className="flex items-start gap-5">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-info-100 to-info-50 border border-info-100 flex items-center justify-center text-info-700 flex-shrink-0">
            <Icon size={28} strokeWidth={1.6} />
          </div>
          <div className="flex-1">
            <CardLabel className="!text-info-700">Coming in Phase 2</CardLabel>
            <h2 className="text-[1.3rem] font-semibold text-ink-900 mt-1.5">
              The full {m.title} interface is being hand-crafted next session.
            </h2>
            <p className="text-[0.95rem] text-ink-600 mt-2 leading-relaxed max-w-3xl">
              The underlying analytical engine is{" "}
              <b className="text-ink-900">already built and tested</b> in the legacy Streamlit
              workspace (24/24 smoke tests passing) — what&apos;s rolling out now is the bespoke
              Next.js UI with full sovereign treatment, smooth interactions, and Recharts
              visualisations. The module reads from the same hash-sealed pipeline you&apos;re
              already inspecting on the four live floors.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link href="/modules/portfolio-x-ray" className="sov-btn sov-btn--primary !text-[0.82rem]">
                <Sparkles size={13} strokeWidth={2} />
                Try Portfolio X-Ray
                <ArrowRight size={13} strokeWidth={2} />
              </Link>
              <Link href="/modules/investor-deep-dive" className="sov-btn sov-btn--ghost !text-[0.82rem]">
                Investor Deep-Dive
              </Link>
              <Link href="/modules/sector-deep-dive" className="sov-btn sov-btn--ghost !text-[0.82rem]">
                Sector Deep-Dive
              </Link>
              <Link href="/modules/audit-vault" className="sov-btn sov-btn--ghost !text-[0.82rem]">
                Audit Vault
              </Link>
            </div>
          </div>
        </div>
      </Card>

      {/* Live data preview — proves the engine is wired even though UI is pending */}
      <Section
        label="Underlying data"
        title="The pipeline this module will read"
        description="These rows are already loaded into the Next.js server. The Phase-2 build wraps them in the bespoke UI."
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <MetricCard label="Investors" value={fmtInt(snap.nInvestors)} accent="gold" />
          <MetricCard
            label="Co-invest edges"
            value={fmtInt(snap.nEdges)}
            sub={`${fmtInt(snap.nNodes)} nodes`}
            accent="info"
          />
          <MetricCard label="Communities" value={fmtInt(snap.nCommunities)} accent="violet" />
          <MetricCard
            label="SMS observations"
            value={fmtInt(snap.nEventPanel)}
            sub={`${fmtInt(snap.nAlphas)} α points`}
            accent="warn"
          />
        </div>
      </Section>
    </div>
  );
}
